<?php
/*
    Template Name: Fast Food Sketch Home
*/

/* Custom Fields 
$prelaunch_price    = get_post_meta(16,'prelaunch_price',true);

*/

/* Advanced Custom Fields */
$home_featured_image   = get_field('home_featured_image');

$sandwich_type_featured_image   = get_field('sandwich_type_featured_image');
$sandwich_type_1_description    = get_field('sandwich_type_1_description');
$sandwich_type_2_description    = get_field('sandwich_type_2_description');
$sandwich_type_3_description    = get_field('sandwich_type_3_description');



get_header(); ?>

<div class="container">
    
    <div class="row">
        
        <div class="col-sm-9">
            
            <section id="big_image">
               <div class="row">
                   <div class="col-sm-12">
                       <img src="<?php echo $home_featured_image['url']; ?> ">
                   </div>
               </div>
            </section>

            <section id="sandwich_type">
                <div class="row">
                    <div class="col-sm-12">
                       <?php echo $sandwich_type_featured_image; ?>
                    </div>
                    <div class="col-sm-4">
                        <?php echo $sandwich_type_1_description; ?>
                    </div>
                    <div class="col-sm-4">
                        <?php echo $sandwich_type_2_description; ?>
                    </div>
                    <div class="col-sm-4">
                        <?php echo $sandwich_type_3_description; ?>
                    </div>

                </div>
            </section> <!-- burger -->
        </div>
        
        <div class="col-sm-3">
            <section id="sidebar">
                <?php get_sidebar(); ?>
            </section>
        </div>
        
    </div> <!-- row -->
    
</div> <!-- container -->

<?php get_footer(); ?>
