<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package prodik
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		<div class="site-info">
            
            <div class="container">
                <div class="row">
                    <div class="col-sm-9">
                        <p>Fast Food Menu is a fast-food restaurant situated on the edge of the earth.</p>
                    </div>
                    <div class="col-sm-3">
                        <p></p>
                    </div>
                </div>
            </div>
            
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php bloginfo('template_directory') ?>/assets/js/jquery-2.1.1.min.js"></script>
    <script src="<?php bloginfo('template_directory') ?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php bloginfo('template_directory') ?>/assets/js/main.js"></script>
    
    <script type="text/javascript" src="//use.typekit.net/gla7wnd.js"></script>
	<script type="text/javascript">try{Typekit.load();}catch(e){}</script>

<?php wp_footer(); ?>

</body>
</html>
